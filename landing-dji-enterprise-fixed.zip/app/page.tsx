import { ArrowRight, BadgeCheck, BookOpenCheck, Building2, GraduationCap, Handshake, RadioTower } from 'lucide-react'
import { ContactForm } from '../components/ContactForm'

const navItems = [
  ['O que fazemos', '#o-que-fazemos'],
  ['Produtos que trabalhamos', '#produtos'],
  ['O que já falam de nós', '#prova'],
  ['Quem somos', '#quem-somos'],
  ['Entrar em contato', '#contato'],
]

const nameIdeas = ['Altitude Partner', 'Nexo Aero', 'Vector Field', 'Orion Works', 'Apta Enterprise', 'Ponto Alto']

export default function Home() {
  return (
    <main>
      <header className="topbar">
        <a href="#inicio" className="brand" aria-label="Início"><span className="brand-mark">AP</span><span>Altitude Partner</span></a>
        <nav aria-label="Menu principal">{navItems.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</nav>
      </header>

      <section id="inicio" className="section hero">
        <div className="hero-copy">
          <p className="eyebrow">DJI Enterprise • canais • treinamento • projetos</p>
          <h1>Mais preparo para vender, implantar e dominar soluções enterprise.</h1>
          <p className="lead">Ajudamos revendas e integradores a estruturarem operação comercial, técnica e de capacitação em produtos DJI Enterprise. Também apoiamos clientes finais que precisam extrair mais valor das soluções que já compraram.</p>
          <div className="hero-actions"><a className="primary" href="#contato">Quero conversar</a><a className="secondary" href="#o-que-fazemos">Ver atuação</a></div>
        </div>
        <div className="hero-card" aria-label="Placeholder visual">
          <div className="drone-placeholder"><RadioTower size={52} /><span>Imagem/hero DJI Enterprise</span></div>
          <div className="metric-row"><strong>Revendas</strong><span>go-to-market, pré-vendas e pós-vendas</span></div>
          <div className="metric-row"><strong>Clientes finais</strong><span>treinamento, operação e maestria</span></div>
        </div>
      </section>

      <section id="o-que-fazemos" className="section split warm">
        <div><p className="eyebrow">O que fazemos</p><h2>Duas frentes, uma operação mais madura.</h2><p>O foco principal é apoiar empresas que querem vender, integrar ou desenvolver negócios com DJI Enterprise. Em paralelo, atendemos clientes finais que precisam treinar equipes, entender aplicações e operar com mais segurança.</p></div>
        <div className="cards two"><article><Handshake /><h3>Para revendas e integradores</h3><p>Estruturação de portfólio, posicionamento, capacitação comercial, suporte técnico de pré-vendas e apoio em oportunidades complexas.</p></article><article><GraduationCap /><h3>Para clientes finais</h3><p>Treinamentos, workshops e consultoria para equipes que querem sair do uso básico e chegar a uma operação consistente.</p></article></div>
      </section>

      <section id="produtos" className="section dark products">
        <div className="section-heading"><p className="eyebrow">Produtos que trabalhamos</p><h2>Ecossistema DJI Enterprise, software e serviços ao redor.</h2></div>
        <div className="product-grid"><article><Building2 /><h3>Drones enterprise</h3><p>Matrice, Mavic Enterprise, sensores, cargas úteis e acessórios.</p></article><article><RadioTower /><h3>Docks e operação remota</h3><p>Projetos com bases autônomas, monitoramento e rotinas de inspeção.</p></article><article><BookOpenCheck /><h3>Software e gestão</h3><p>FlightHub 2, fluxos operacionais, governança e documentação.</p></article><article><BadgeCheck /><h3>Capacitação</h3><p>Treinamentos comerciais, técnicos e operacionais para times internos e parceiros.</p></article></div>
      </section>

      <section id="prova" className="section proof">
        <div className="quote-card"><p className="eyebrow">O que já falam de nós</p><blockquote>“Placeholder para depoimento de parceiro, cliente ou case. Aqui entra uma frase curta, específica e com nome autorizado.”</blockquote><span>Nome Sobrenome, Empresa</span></div>
        <div className="proof-list"><h2>Use esta seção como vitrine de confiança.</h2><p>Enquanto não houver depoimentos públicos, você pode usar marcos objetivos: treinamentos realizados, parceiros atendidos, projetos acompanhados, certificações e autorizações de marca.</p><ul><li>Depoimentos curtos com autorização.</li><li>Cases sem dados sensíveis.</li><li>Números reais, sem inflar promessa.</li></ul></div>
      </section>

      <section id="quem-somos" className="section split about">
        <div><p className="eyebrow">Quem somos</p><h2>Um time próximo do campo, da venda e da operação.</h2><p>Somos profissionais conectados ao ecossistema DJI Enterprise no Brasil. Atuamos entre o comercial e o técnico: traduzimos produto em aplicação, aplicação em projeto, e projeto em operação viável.</p><p className="muted">Troque este texto quando o nome, sócios e posicionamento final estiverem definidos.</p></div>
        <div className="name-panel"><h3>Ideias de nome</h3><div className="name-tags">{nameIdeas.map((name) => <span key={name}>{name}</span>)}</div><p>Minha preferência inicial: <strong>Altitude Partner</strong>. É simples, soa enterprise e não prende a marca somente a drones.</p></div>
      </section>

      <section id="contato" className="section contact">
        <div className="contact-copy"><p className="eyebrow">Entrar em contato</p><h2>Conte onde você quer chegar.</h2><p>Se você é revenda, integrador ou cliente final, envie os dados abaixo. A ideia é responder com o caminho mais prático: conversa comercial, treinamento, diagnóstico técnico ou desenho de projeto.</p><div className="privacy-note"><strong>Privacidade:</strong> os dados do formulário devem ir para Supabase ou Notion com acesso restrito. Não salve leads no GitHub, não exponha chaves privadas e mantenha o repositório privado enquanto a marca não estiver lançada.</div></div>
        <ContactForm />
      </section>
    </main>
  )
}
