# Landing page - DJI Enterprise Enablement

Projeto inicial de landing page em Next.js para uma empresa focada em revendas/integradores DJI Enterprise e, em segundo plano, clientes finais que buscam treinamento e domínio das soluções.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Variáveis de ambiente

Copie `.env.example` para `.env.local`.

```bash
cp .env.example .env.local
```

Para usar Supabase no formulário:

```env
NEXT_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=SUA_ANON_KEY
NEXT_PUBLIC_CONTACT_DESTINATION=supabase
```

Sem Supabase configurado, o formulário exibe uma simulação de envio para facilitar o teste visual.

## Tabela sugerida no Supabase

```sql
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  company text,
  email text not null,
  whatsapp text,
  location text,
  interest text not null,
  message text,
  status text not null default 'novo'
);

alter table public.leads enable row level security;

create policy "Public lead insert"
on public.leads
for insert
to anon
with check (true);
```

Não crie policy de leitura pública. A leitura deve ficar restrita ao painel interno/Supabase ou a uma futura área autenticada.
